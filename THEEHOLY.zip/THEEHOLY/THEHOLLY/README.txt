Please note you'll have to turn off "Real-time-protection" in your settings order to run this file after running you may turn it back on if you want it to work 100% with no error please leave off. Enjoy

Steps: click your windows button search up "Virus & threat protection" click on manage settings and click "Real-time protection ~ Windows 10